const search=document.getElementById("search-input");
const searchButton=document.getElementById("search-button");
searchButton.addEventListener("click",(e)=>{
    //e.preventDefault();
    console.log(search.value);
})