
/** @type {import('tailwindcss').Config} */
export default {
  content:["./src/views/*.ejs",
"public//scripts/*.js",
],
  theme: {
    extend: {},
  },
  plugins: [],
}

